# Archivos Clave para Exportar (Handover a Desarrolladores)

Para que tu equipo de desarrollo pueda realizar un análisis completo y continuar el trabajo sin fricción, necesitan "la foto completa" del sistema: Configuración Base, Base de Datos, Autenticación y Lógica de Negocio.

He seleccionado los archivos mínimos indispensables que componen el "Core" del sistema actual.

## Lista de Archivos Prioritarios

### 1. Configuración e Infraestructura
*Esencial para levantar el entorno y entender las dependencias.*
- `package.json` (Dependencias y scripts)
- `next.config.mjs` (Configuración del framework)
- `.env` (OJO: **NO** exportar las claves reales, crear un `.env.example` con valores vacíos)

### 2. Base de Datos
*El corazón del sistema. Define la estructura de datos.*
- `prisma/schema.prisma` (Modelo de datos: Socios, Usuarios, Logs, Partidos)

### 3. Autenticación y Seguridad
*Cómo se manejan los accesos y sesiones.*
- `src/lib/auth.js` (Lógica central de login y providers)
- `src/app/api/auth/[...nextauth]/route.js` (Endpoint de manejo de sesión)

### 4. API Backend (Lógica de Negocio)
*Endpoints que conectan el frontend con la base de datos.*
- `src/lib/db.js` (Conector de Prisma client)
- `src/app/api/member/route.js` (Lógica de perfil de usuario)
- `src/app/api/members/route.js` (Lógica del padrón de socios)

### 5. Frontend (Core Application)
*La interfaz principal donde ocurre la lógica visual.*
- `src/app/layout.js` (Estructura global)
- `src/app/page.js` (Contenedor principal, manejo de estado y navegación)
- `src/app/globals.css` (Estilos base Tailwind)

### 6. Componentes Clave
*Bloques funcionales de la UI.*
- `src/components/LoginScreen.jsx` (Pantalla de acceso)
- `src/components/Header.jsx` y `src/components/Sidebar.jsx` (Navegación)
- `src/components/DigitalID.jsx` (Carnet digital)

### 7. Secciones Funcionales (Business Logic)
*Lógica específica de cada módulo.*
- `src/components/sections/DashboardSection.jsx` (Buscador y métricas)
- `src/components/sections/MemberProfileSection.jsx` (Ficha del socio)
- `src/components/sections/EntradasSection.jsx` (Venta de tickets)
- `src/components/sections/AltaExpressSection.jsx` (Nuevos socios)

---

## Cómo Exportar Todo Rápido

Si tenés acceso a una terminal, podés ejecutar este comando para generar un archivo `casla_handover.zip` con exactamente estos archivos, manteniendo la estructura de carpetas:

```bash
zip -r casla_handover.zip \
  package.json \
  next.config.mjs \
  prisma/schema.prisma \
  src/lib/auth.js \
  src/lib/db.js \
  src/app/api \
  src/app/layout.js \
  src/app/page.js \
  src/app/globals.css \
  src/components
```
*(Nota: Esto incluye toda la carpeta `components` para asegurar que no falte ninguna dependencia interna)*.

**¿Qué NO hace falta enviar?**
- `node_modules/` (Es muy pesado y se reinstala con `npm install`)
- `.next/` (Archivos de build generados)
- `.git/` (El historial de versiones, a menos que les des acceso al repo completo)
