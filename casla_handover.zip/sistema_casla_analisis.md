# Análisis Funcional del Sistema CASLA (Backend & Frontend)

**Versión del Documento:** 1.0
**Fecha:** 13 de Febrero de 2026
**Plataforma Actual:** Vercel (Next.js + PostgreSQL)

## 1. Visión General
El sistema actual ("Portal Socios 5.1") es una aplicación web progresiva (PWA) construida con **Next.js 16.1** y **React 19**, diseñada para la administración y gestión de socios del Club Atlético San Lorenzo de Almagro. 

Actualmente, el sistema opera en una modalidad híbrida:
- **Backend:** Conectado a una base de datos PostgreSQL real vía Prisma ORM.
- **Autenticación:** Sistema de credenciales hardcodeadas (fase de desarrollo/demo) con roles de staff.
- **Frontend:** Interfaz de usuario "Rich UI" con TailwindCSS, que combina datos en tiempo real con datos estáticos para funcionalidades aún no conectadas a BD.

## 2. Arquitectura Técnica

### Stack Tecnológico
- **Framework:** Next.js 16.1 (App Router)
- **Lenguaje:** JavaScript / React
- **Estilos:** TailwindCSS v4 + Lucide React (Íconos)
- **Base de Datos:** PostgreSQL (@vercel/postgres)
- **ORM:** Prisma v7.3.0
- **Autenticación:** NextAuth.js v4 (Credentials Provider)

### Estructura de APIs (`src/app/api`)
El sistema expone endpoints RESTful consumidos por el propio frontend:
1.  **`GET /api/member`**: 
    -   Intenta recuperar el perfil del usuario logueado.
    -   *Lógica actual:* Busca un usuario por email en DB. Si no tiene un "Member" asociado explícitamente, retorna el primer socio encontrado en la base de datos (`prisma.member.findFirst()`) o data mockeada si falla la DB.
2.  **`GET /api/members`**:
    -   Retorna el padrón completo de socios (`prisma.member.findMany()`).
    -   Utilizado para el buscador global y la base de datos de gestión.

## 3. Modelo de Datos (Prisma Schema)

El esquema actual define las siguientes entidades clave:

### `Member` (Socio)
La entidad central. Contiene:
-   **Identificación:** `dni`, `memberNumber` (N° Socio), `fullName`.
-   **Estado:** `category` (Activo, Cadete), `status` (AL DÍA, MOROSO), `seniority`.
-   **Digital ID:** `qrToken` (Token rotativo para acceso), `avatarUrl`.
-   **Derechos/Abonos:** `seatLocation`, `sector`, `gate`.
-   **Relaciones:** Tiene múltiples `AccessLog`.

### `User` (Operador del Sistema)
Usuarios internos que acceden al portal (Staff/Admin).
-   Campos: `email`, `password`, `role` (ADMIN, STAFF).
-   *Nota:* Actualmente desconectado del sistema de login principal (`auth.js` usa usuarios en código).

### `Match` (Partido)
Información de eventos deportivos para la gestión de entradas y accesos.
-   Campos: `rival`, `date`, `time`, `isClassic`, `isLocal`.

### `AccessLog` (Control de Acceso)
Registro de intentos de ingreso.
-   Campos: `gate`, `status` (GRANTED/DENIED), timestamp.

## 4. Perfiles de Usuario y Permisos

El sistema implementa un control de acceso basado en roles (RBAC) definido en `src/lib/auth.js` y `src/app/page.js`.

### A. Administrador (`admin`)
-   **Credenciales:** `admin` / `admin`
-   **Permisos:**
    -   Acceso total al Dashboard.
    -   **Edición de Partidos:** Puede modificar rivales, horarios y precios de entradas sin aprobación.
    -   Visualización de métricas de negocio.
    -   Gestión de ABM de socios.

### B. Staff / Operador (`oper`)
-   **Credenciales:** `oper` / `oper`
-   **Permisos:**
    -   Búsqueda y visualización de socios.
    -   Generación de tickets/entradas.
    -   Consulta de guías de trámites.
-   **Restricciones:** 
    -   **Solicitud de Cambios:** Al intentar editar un partido, el sistema no guarda el cambio directamente, sino que genera una "Solicitud de Aprobación" (`pendingApprovals`) que debe ser visada por un Admin.

### C. Socio (Usuario Final)
-   *Estado Actual:* No existe un login directo para el socio ("MiCASLA") conectado a la base de datos `Member`.
-   El perfil de socio es visualizado por el Staff/Admin a través del buscador.

## 5. Análisis de Módulos Funcionales

### 1. Dashboard & Buscador (`DashboardSection`)
-   **Funcionalidad:** Buscador en tiempo real sobre el array de socios descargado.
-   **Lógica:** Filtra por Nombre, DNI o N° de Socio.
-   **Interacción:** Al seleccionar un resultado, despliega el `MemberProfileSection`.

### 2. Perfil de Socio (`MemberProfileSection`)
-   **Visualización:** Ficha técnica con foto, estado de deuda, categoría y último acceso.
-   **Digital ID:** Muestra el carnet digital.

### 3. Boletería & Accesos (`EntradasSection`)
-   **Gestión de Partidos:** Listado de próximos eventos.
-   **Emisión de Tickets:**
    -   Genera un QR dinámico (`api.qrserver.com`) con datos del sector y partido.
    -   Permite compartir el ticket vía **WhatsApp** (integración `wa.me` con mensaje pre-armado).

### 4. Gestión de Espacios (`EspaciosSection`)
-   **Catálogo:** Muestra Quinchos y Canchas (Tenis, Pando).
-   **Estado:** Disponible / Ocupado / Mantenimiento.
-   *Nota:* La lógica de reserva actual es visual; el botón "Gestionar" muestra una alerta de "Funcionalidad en desarrollo".

### 5. Base de Conocimiento & Scripts (`ScriptsSection`)
-   **Herramienta de Soporte:** Provee a los operadores scripts pre-definidos para responder consultas por WhatsApp/Email (e.g., "Mora", "Bienvenida", "Error de Cobro").
-   **FAQ:** Respuestas rápidas para atención al socio.

## 6. Estado Actual vs. Producción Ideal

| Característica | Estado Actual (Código Analizado) | Requerimiento Producción Real |
| :--- | :--- | :--- |
| **Login** | Hardcoded (`admin`/`admin`) | Integrar `prisma.user` con hash de contraseñas. |
| **Vinculación** | `findFirst()` (Usuario genérico) | Vincular `User.email` con `Member.dni/email`. |
| **Datos Partidos** | State local (`useState`) | Leer/Escribir en tabla `Match` de DB. |
| **Pagos** | Simulado (Solo UI) | Integración con Gateway de Pagos. |
| **QR Acceso** | Generado al vuelo (sin persistencia) | Guardar `qrToken` en DB y validar en molinetes. |

## 7. Conclusión para Desarrolladores

El sistema tiene un **Frontend robusto y pulido** con una arquitectura de componentes clara. El **Backend** tiene la infraestructura lista (Prisma, Postgres) pero la lógica de negocio ("Business Logic Layer") está actualmente en un estado de demostración, donde muchas operaciones de escritura ocurren en la memoria del cliente (React State) en lugar de persistirse en la base de datos. 

**Próximos Pasos Técnicos Sugeridos:**
1.  Migrar la autenticación de `CredentialsProvider` hardcodeado a consulta contra la tabla `User`.
2.  Conectar las acciones de "Guardar Partido" y "Generar Ticket" a Server Actions o API Routes que escriban en PostgreSQL.
3.  Implementar la relación real 1:1 entre la cuenta de usuario logueado y su registro de `Member` correspondiente.
